function output = No_Entropy_Quantize(mat,qmat)
output = round(mat./qmat);
end

