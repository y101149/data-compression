function output = No_Entropy_Dequantize(mat,qmat)
output = (mat.*qmat);
end